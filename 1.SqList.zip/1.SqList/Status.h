#ifndef STATUS_H
#define STATUS_H

typedef enum {
    OK = 0,
    ERROR = -1
} Status;

#endif // STATUS_H